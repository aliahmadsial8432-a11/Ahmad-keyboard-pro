package com.ahmad.keyboard.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.ahmad.keyboard.data.SocialLinks
import com.ahmad.keyboard.theme.chip
import com.ahmad.keyboard.theme.dp

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F1117.toInt())
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }
        fun btn(label: String, bg: Int = 0xFF1C1F2A.toInt(), fg: Int = Color.WHITE, onClick: () -> Unit) {
            page.addView(chip(label, bg, fg, 12, 16f, onClick).apply {
                layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(0, dp(5), 0, dp(5)) }
            })
        }
        page.addView(TextView(this).apply {
            text = "Ahmad Keyboard Pro"; textSize = 26f; setTextColor(0xFFD4FF00.toInt())
        })
        page.addView(TextView(this).apply {
            text = "1) Enable the keyboard  2) Select it  3) Try it below"
            setTextColor(Color.LTGRAY); setPadding(0, dp(6), 0, dp(10))
        })
        btn("1 · Enable keyboard", 0xFFD4FF00.toInt(), 0xFF111111.toInt()) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        btn("2 · Select keyboard") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        page.addView(EditText(this).apply {
            hint = "3 · Tap here to test…"; setTextColor(Color.WHITE); setHintTextColor(0xFF888888.toInt())
        })
        btn("✍️ Designer Studio Pad") { startActivity(Intent(this, StudioActivity::class.java)) }
        page.addView(TextView(this).apply {
            text = "★ Creator Hub"; textSize = 20f; setTextColor(Color.WHITE); setPadding(0, dp(14), 0, dp(4))
        })
        SocialLinks.all.forEach { (n, u) -> btn(n) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } }
        setContentView(ScrollView(this).apply { addView(page) })
    }
}

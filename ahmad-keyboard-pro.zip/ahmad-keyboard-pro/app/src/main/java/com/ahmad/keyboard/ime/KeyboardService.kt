package com.ahmad.keyboard.ime

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.ahmad.keyboard.data.Kaomojis
import com.ahmad.keyboard.data.SocialLinks
import com.ahmad.keyboard.engine.FontTransformer
import com.ahmad.keyboard.theme.KbTheme
import com.ahmad.keyboard.theme.Themes
import com.ahmad.keyboard.theme.chip
import com.ahmad.keyboard.theme.dp

class KeyboardService : InputMethodService() {
    companion object { var instance: KeyboardService? = null }

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var panelBox: FrameLayout
    private lateinit var keysBox: LinearLayout
    private var theme: KbTheme = Themes.all[0]
    private var shift = false
    private var mode = 0              // 0 = English, 1 = symbols, 2 = Urdu
    private var fontIndex = -1        // -1 = normal typing
    private var openPanel: String? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = getSharedPreferences("akp", Context.MODE_PRIVATE)
    }

    override fun onDestroy() { instance = null; super.onDestroy() }

    override fun onCreateInputView(): View {
        theme = Themes.byName(prefs.getString("theme", null))
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        build()
        return root
    }

    fun commit(t: String) { currentInputConnection?.commitText(t, 1) }

    private fun open(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- layout ----------
    private fun build() {
        root.removeAllViews()
        root.setBackgroundColor(theme.bg)
        openPanel = null

        val tools: List<Pair<String, () -> Unit>> = listOf(
            "★" to { showPanel("hub") },
            "aあ" to { showPanel("fonts") },
            "🎨" to { showPanel("themes") },
            "🧸" to { showPanel("kaomoji") },
            "📋" to { showPanel("clip") },
            "🎙" to {
                startActivity(Intent(this, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            "اردو" to { mode = if (mode == 2) 0 else 2; rebuildKeys() }
        )
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.forEach { (label, action) ->
            bar.addView(chip(label, theme.key, theme.text, theme.corner, 15f) { action() }.apply {
                layoutParams = LinearLayout.LayoutParams(WRAP_CONTENT, dp(38)).apply { setMargins(dp(4), dp(4), dp(4), dp(2)) }
            })
        }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(bar) })

        panelBox = FrameLayout(this).apply { visibility = View.GONE }
        root.addView(panelBox)

        keysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysBox)
        rebuildKeys()
    }

    private fun key(label: String, w: Float = 1f, bg: Int = theme.key, fg: Int = theme.text, onTap: () -> Unit): TextView =
        chip(label, bg, fg, theme.corner, 18f, onTap).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(46), w).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            setPadding(0, 0, 0, 0)
        }

    private fun rebuildKeys() {
        keysBox.removeAllViews()
        val rows = when (mode) {
            0 -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
            1 -> listOf("1234567890", "@#\$%&-+()/", "*\"':;!?")
            else -> listOf("قوعرتےءیہپ", "اسدفگحجکل", "زشچطبنم")
        }
        rows.forEachIndexed { idx, chars ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (idx == 2 && mode == 0) {
                row.addView(key(if (shift) "⇧" else "⇪", 1.5f, if (shift) theme.accent else theme.key, if (shift) 0xFF111111.toInt() else theme.text) {
                    shift = !shift; rebuildKeys()
                })
            }
            chars.forEach { c ->
                val label = if (mode == 0 && shift) c.uppercase() else c.toString()
                row.addView(key(label) { typeKey(c.toString()) })
            }
            if (idx == 2) row.addView(key("⌫", 1.5f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
            keysBox.addView(row)
        }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(key(if (mode == 1) "ABC" else "123", 1.3f) { mode = if (mode == 1) 0 else 1; rebuildKeys() })
        bottom.addView(key(if (mode == 2) "ABC" else "اردو", 1.3f) { mode = if (mode == 2) 0 else 2; rebuildKeys() })
        bottom.addView(key(if (fontIndex >= 0) FontTransformer.styles[fontIndex].name else "space", 4f) { commit(" ") })
        bottom.addView(key(".", 1f) { commit(".") })
        bottom.addView(key("⏎", 1.3f, theme.accent, 0xFF111111.toInt()) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) })
        keysBox.addView(bottom)
    }

    private fun typeKey(c: String) {
        var t = if (mode == 0 && shift) c.uppercase() else c
        if (mode == 0 && fontIndex >= 0) t = FontTransformer.styles[fontIndex].apply(t)
        commit(t)
        if (shift) { shift = false; rebuildKeys() }
    }

    // ---------- panels ----------
    private fun showPanel(kind: String) {
        panelBox.removeAllViews()
        if (openPanel == kind) { openPanel = null; panelBox.visibility = View.GONE; return }
        openPanel = kind
        panelBox.visibility = View.VISIBLE

        val items: List<Pair<String, () -> Unit>>
        var cols = 3
        when (kind) {
            "hub" -> {
                cols = 2
                items = SocialLinks.all.map { (n, u) -> n to { open(u) } }
            }
            "fonts" -> {
                val list = mutableListOf<Pair<String, () -> Unit>>("Normal" to { fontIndex = -1; rebuildKeys() })
                FontTransformer.styles.forEachIndexed { i, s ->
                    list.add(s.apply("Abc 123") to { fontIndex = i; rebuildKeys() })
                }
                items = list
            }
            "themes" -> {
                cols = 2
                items = Themes.all.map { t ->
                    t.name to { prefs.edit().putString("theme", t.name).apply(); theme = t; build() }
                }
            }
            "kaomoji" -> {
                items = Kaomojis.all.map { k -> k to { commit(k) } }
            }
            else -> {
                cols = 1
                val pins = prefs.getStringSet("pins", emptySet())!!.toList()
                val cur = (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
                val list = mutableListOf<Pair<String, () -> Unit>>()
                if (cur != null) {
                    list.add("📋 $cur" to { commit(cur) })
                    list.add("📌 Pin current clip" to {
                        prefs.edit().putStringSet("pins", pins.toSet() + cur).apply(); showPanel("clip"); showPanel("clip")
                    })
                }
                pins.forEach { p -> list.add("📌 $p" to { commit(p) }) }
                if (list.isEmpty()) list.add("Nothing copied yet" to {})
                items = list
            }
        }
        panelBox.addView(grid(items, cols))
    }

    private fun grid(items: List<Pair<String, () -> Unit>>, cols: Int): View {
        val sv = ScrollView(this).apply { layoutParams = FrameLayout.LayoutParams(MATCH_PARENT, dp(150)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.chunked(cols).forEach { r ->
            val rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.forEach { (t, a) ->
                rowL.addView(chip(t, theme.key, theme.text, theme.corner, 15f) { a() }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                })
            }
            repeat(cols - r.size) { rowL.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            col.addView(rowL)
        }
        sv.addView(col)
        return sv
    }
}

package com.ahmad.keyboard.theme

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.chip(
    label: String, bg: Int, fg: Int, radiusDp: Int = 10, sizeSp: Float = 16f, onClick: () -> Unit
): TextView = TextView(this).apply {
    this.text = label
    gravity = Gravity.CENTER
    setTextColor(fg)
    textSize = sizeSp
    background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(radiusDp).toFloat() }
    setPadding(dp(10), dp(8), dp(10), dp(8))
    setOnClickListener { onClick() }
}
